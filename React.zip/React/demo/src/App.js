// functional component example
// import './App.css';
// import Heading from './component/Heading'

// function App() {
//   return (
//     <Heading/>
//   );
// }

// export default App;


// class component  example

import './App.css';
import Heading from './component/FunctionalComponent'
import Myclass from './component/ClassComponent';

function App() {
  return (
    <>
    <Heading/>
    <Myclass/>
    </>
  );
}

export default App;
