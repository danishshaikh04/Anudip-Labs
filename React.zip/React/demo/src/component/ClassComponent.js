import React from "react";

class Myclass extends React.Component {
  render() {
    return (
      <h1>This Message is displayed using  the Class Component</h1>
    );
  }
}

export default Myclass;