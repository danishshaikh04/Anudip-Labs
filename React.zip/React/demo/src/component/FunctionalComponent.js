
function Heading() {
  return (
    <div>
      <h1>This Message is displayed using the Functional Component</h1>
    </div>
  )
}

export default Heading



